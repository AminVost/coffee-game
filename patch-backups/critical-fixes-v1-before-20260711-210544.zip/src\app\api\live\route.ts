import { NextResponse } from "next/server";
import { liveMatches } from "@/data/mock-data";
export const dynamic="force-dynamic";
export async function GET(){return NextResponse.json({items:liveMatches,updatedAt:new Date().toISOString()},{headers:{"Cache-Control":"no-store"}})}
