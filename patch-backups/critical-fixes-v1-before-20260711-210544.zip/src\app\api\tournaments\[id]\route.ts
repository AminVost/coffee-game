import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { execute } from "@/lib/db";
import { env } from "@/lib/env";
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});const {id}=await params;const data=await request.json();if(env.dataMode==="mock")return NextResponse.json({ok:true,id,data});await execute(`UPDATE tournaments SET title=COALESCE(?,title),status=COALESCE(?,status),updated_at=NOW() WHERE id=?`,[data.title||null,data.status||null,id]);return NextResponse.json({ok:true});}
export async function DELETE(_:Request,{params}:{params:Promise<{id:string}>}){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});const {id}=await params;if(env.dataMode!=="mock")await execute(`UPDATE tournaments SET deleted_at=NOW() WHERE id=?`,[id]);return NextResponse.json({ok:true});}
