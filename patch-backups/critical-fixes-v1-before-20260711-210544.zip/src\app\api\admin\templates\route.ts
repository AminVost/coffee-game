import { NextResponse } from "next/server";
import { z } from "zod";
import type { RowDataPacket } from "mysql2";
import { getSession } from "@/lib/auth";
import { execute, queryRows } from "@/lib/db";
import { env } from "@/lib/env";
const schema=z.object({title:z.string().min(3),gameId:z.number().int(),configuration:z.record(z.string(),z.unknown())});
export async function GET(){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});if(env.dataMode==="mock")return NextResponse.json({items:[{id:"1",title:"جام هفتگی FC 26"},{id:"2",title:"تخته‌نرد هفت‌امتیازی"}]});const rows=await queryRows<RowDataPacket[]>(`SELECT tt.*,g.title AS game_title FROM tournament_templates tt JOIN games g ON g.id=tt.game_id WHERE tt.is_active=1 ORDER BY tt.updated_at DESC`);return NextResponse.json({items:rows})}
export async function POST(request:Request){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});try{const input=schema.parse(await request.json());if(env.dataMode==="mock")return NextResponse.json({ok:true,id:"mock-template"},{status:201});const result=await execute(`INSERT INTO tournament_templates(game_id,title,configuration,is_active,created_by,created_at,updated_at) VALUES(?,?,?,1,?,NOW(),NOW())`,[input.gameId,input.title,JSON.stringify(input.configuration),user.id]);return NextResponse.json({ok:true,id:String(result.insertId)},{status:201});}catch{return NextResponse.json({message:"داده قالب نامعتبر است"},{status:422});}}
