import { NextResponse } from "next/server";
import { z } from "zod";
import { setSession } from "@/lib/auth";
import { env } from "@/lib/env";
const schema=z.object({mobile:z.string().regex(/^09\d{9}$/),code:z.string().length(6)});
export async function POST(request:Request){try{const input=schema.parse(await request.json());if(input.code!==env.mockSmsCode)return NextResponse.json({message:"کد تایید نادرست است."},{status:401});await setSession({id:"sms-demo",name:"کاربر پیامکی",mobile:input.mobile,role:"player"});return NextResponse.json({ok:true,role:"player"});}catch{return NextResponse.json({message:"اطلاعات تایید نامعتبر است."},{status:422});}}
