import type { Metadata } from "next";
import { Radio, RefreshCw } from "lucide-react";
import { LiveMatchCard } from "@/components/live-match-card";
import { Button } from "@/components/ui/button";
import { liveMatches } from "@/data/mock-data";
export const metadata: Metadata={title:"نتایج زنده"};
export default function LivePage(){return <div className="page-shell"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="section-kicker">LIVE CENTER</p><h1 className="section-title mt-2 flex items-center gap-3"><Radio className="text-red-500"/>نتایج و برنامه زنده</h1><p className="mt-3 text-sm text-[var(--muted)]">این صفحه برای موبایل، دسکتاپ و نمایشگر مجموعه طراحی شده است.</p></div><Button variant="secondary" size="sm"><RefreshCw size={16}/>بروزرسانی</Button></div><div className="mt-8 grid gap-4 lg:grid-cols-2">{liveMatches.map(m=><LiveMatchCard key={m.id} match={m}/>)}</div></div>}
