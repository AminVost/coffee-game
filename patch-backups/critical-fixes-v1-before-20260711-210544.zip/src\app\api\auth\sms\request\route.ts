import { NextResponse } from "next/server";
import { z } from "zod";
import { env } from "@/lib/env";
const schema=z.object({mobile:z.string().regex(/^09\d{9}$/)});
export async function POST(request:Request){try{const {mobile}=schema.parse(await request.json());return NextResponse.json({ok:true,mobile,message:env.dataMode==="mock"?`کد آزمایشی ${env.mockSmsCode} است.`:"کد ارسال شد."});}catch{return NextResponse.json({message:"شماره موبایل نامعتبر است."},{status:422});}}
