import { NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth";
import { execute } from "@/lib/db";
import { env } from "@/lib/env";
import { listTournaments } from "@/lib/repositories/tournaments";
export async function GET(){return NextResponse.json({items:await listTournaments()})}
const schema=z.object({title:z.string().min(3),slug:z.string().min(3),gameId:z.number().int(),format:z.string(),capacity:z.number().int().min(2),price:z.number().int().min(0),startsAt:z.string().datetime(),venueId:z.number().int().optional()});
export async function POST(request:Request){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});try{const input=schema.parse(await request.json());if(env.dataMode==="mock")return NextResponse.json({ok:true,id:"mock-new-tournament"},{status:201});const result=await execute(`INSERT INTO tournaments(public_id,slug,title,game_id,venue_id,format,participant_type,team_size,capacity,min_participants,price,currency,status,starts_at,reservation_expires_min,late_tolerance_min,waitlist_mode,allow_multi_slot,has_third_place,draw_mode,created_at,updated_at) VALUES(UUID(),?,?,?,?,?,'INDIVIDUAL',1,?,2,?,'TOMAN','DRAFT',?,30,10,'offer',0,0,'random',NOW(),NOW())`,[input.slug,input.title,input.gameId,input.venueId||null,input.format,input.capacity,input.price,new Date(input.startsAt)]);return NextResponse.json({ok:true,id:String(result.insertId)},{status:201});}catch(error){if(error instanceof z.ZodError)return NextResponse.json({message:"داده مسابقه نامعتبر است",errors:error.issues},{status:422});return NextResponse.json({message:"ثبت مسابقه انجام نشد"},{status:500});}}
