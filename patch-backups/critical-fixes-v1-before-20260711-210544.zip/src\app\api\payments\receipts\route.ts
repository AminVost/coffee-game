import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
const allowed=new Set(["image/jpeg","image/png","application/pdf"]);const maxSize=5*1024*1024;
export async function POST(request:Request){const user=await getSession();if(!user)return NextResponse.json({message:"ابتدا وارد شوید"},{status:401});const form=await request.formData();const file=form.get("file");if(!(file instanceof File))return NextResponse.json({message:"فایل ارسال نشده است"},{status:422});if(!allowed.has(file.type)||file.size>maxSize)return NextResponse.json({message:"فقط JPG، PNG یا PDF تا ۵ مگابایت مجاز است"},{status:422});const ext=file.type==="application/pdf"?"pdf":file.type==="image/png"?"png":"jpg";const name=`${randomUUID()}.${ext}`;const dir=path.join(process.cwd(),"storage","receipts");await mkdir(dir,{recursive:true});await writeFile(path.join(dir,name),Buffer.from(await file.arrayBuffer()));return NextResponse.json({ok:true,file:name});}
