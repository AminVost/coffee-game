"use client";

import { useState } from "react";
import { CheckCircle2, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Tournament } from "@/types";

export function RegisterTournamentForm({ tournament }: { tournament: Tournament }) {
  const [players, setPlayers] = useState([{ name: "", mobile: "" }]);
  const [payment, setPayment] = useState("online");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  function update(index: number, key: "name" | "mobile", value: string) {
    setPlayers((items) => items.map((item, i) => i === index ? { ...item, [key]: value } : item));
  }
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setLoading(true);
    const response = await fetch("/api/registrations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tournamentId: tournament.id, players, payment }) });
    setLoading(false); if (response.ok) setDone(true);
  }
  if (done) return <div className="rounded-[1.75rem] border border-emerald-500/25 bg-emerald-500/10 p-7 text-center"><CheckCircle2 className="mx-auto text-emerald-500" size={48}/><h3 className="mt-4 text-xl font-black">رزرو آزمایشی ثبت شد</h3><p className="mt-2 text-sm leading-7 text-[var(--muted)]">کد پیگیری و QR در پنل کاربری نمایش داده می‌شود. در حالت MySQL این اطلاعات در دیتابیس ذخیره خواهد شد.</p></div>;
  return <form onSubmit={submit} className="grid gap-5">
    <div><h3 className="font-black">شرکت‌کنندگان</h3><p className="mt-1 text-xs text-[var(--muted)]">خریدار می‌تواند چند سهم برای شماره‌های متفاوت رزرو کند.</p></div>
    {players.map((player, index) => <div key={index} className="grid gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-4 sm:grid-cols-[1fr_1fr_auto]"><input className="field" placeholder="نام و نام خانوادگی" value={player.name} onChange={(e) => update(index,"name",e.target.value)} required/><input className="field" placeholder="شماره موبایل" dir="ltr" value={player.mobile} onChange={(e) => update(index,"mobile",e.target.value)} required/><button type="button" disabled={players.length === 1} onClick={() => setPlayers(players.filter((_,i) => i !== index))} className="grid h-11 w-11 cursor-pointer place-items-center rounded-xl border border-[var(--line)] text-red-500 disabled:opacity-30"><Trash2 size={17}/></button></div>)}
    <Button type="button" variant="secondary" onClick={() => setPlayers([...players,{name:"",mobile:""}])}><Plus size={17}/>افزودن سهم دیگر</Button>
    <label className="field-label">روش پرداخت<select className="field" value={payment} onChange={(e) => setPayment(e.target.value)}><option value="online">درگاه آزمایشی</option><option value="cash">پرداخت حضوری</option><option value="receipt">آپلود فیش</option></select></label>
    <Button type="submit" disabled={loading}>{loading ? "در حال ثبت..." : `رزرو ${players.length.toLocaleString("fa-IR")} سهم`}</Button>
  </form>;
}
