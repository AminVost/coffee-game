import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { adminStats, recentRegistrations } from "@/data/mock-data";
export async function GET(){const user=await getSession();if(user?.role!=="admin")return NextResponse.json({message:"دسترسی غیرمجاز"},{status:403});return NextResponse.json({stats:adminStats,recentRegistrations})}
