import { compare } from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import type { RowDataPacket } from "mysql2";
import { setSession } from "@/lib/auth";
import { queryRows } from "@/lib/db";
import { env } from "@/lib/env";

const schema=z.object({email:z.string().min(3),password:z.string().min(4)});
type UserRow=RowDataPacket & {id:number;name:string;email:string|null;mobile:string|null;password_hash:string|null;status:string;role_name:string|null};
export async function POST(request:Request){
  try{
    const input=schema.parse(await request.json());
    if(env.dataMode==="mock"){
      const admin=input.email==="admin@coffeegame.local"&&input.password==="Admin@123";
      const player=input.email==="player@coffeegame.local"&&input.password==="Player@123";
      if(!admin&&!player)return NextResponse.json({message:"اطلاعات ورود آزمایشی نادرست است."},{status:401});
      const user=admin?{id:"1",name:"مدیر اصلی",email:input.email,role:"admin" as const}:{id:"2",name:"بازیکن آزمایشی",email:input.email,role:"player" as const};
      await setSession(user);return NextResponse.json({ok:true,role:user.role});
    }
    const rows=await queryRows<UserRow[]>(`SELECT u.id,u.name,u.email,u.mobile,u.password_hash,u.status,r.name AS role_name FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id WHERE (u.email=? OR u.mobile=?) AND u.deleted_at IS NULL LIMIT 1`,[input.email,input.email]);
    const user=rows[0];
    if(!user?.password_hash||!(await compare(input.password,user.password_hash)))return NextResponse.json({message:"ایمیل، موبایل یا رمز عبور نادرست است."},{status:401});
    if(user.status!=="ACTIVE")return NextResponse.json({message:"حساب کاربری فعال نیست."},{status:403});
    const role=["super_admin","manager"].includes(user.role_name||"")?"admin":"player";
    await setSession({id:String(user.id),name:user.name,email:user.email||undefined,mobile:user.mobile||undefined,role});
    return NextResponse.json({ok:true,role});
  }catch(error){if(error instanceof z.ZodError)return NextResponse.json({message:"ورودی نامعتبر است.",errors:error.issues},{status:422});return NextResponse.json({message:"خطای داخلی در ورود."},{status:500});}
}
