export const env = {
  dataMode: process.env.DATA_MODE === "mysql" ? "mysql" : "mock",
  authSecret: process.env.AUTH_SECRET || "unsafe-development-secret",
  appUrl: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
  mockSmsCode: process.env.MOCK_SMS_CODE || "123456"
} as const;
