/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Clipboard, Eye, Search, X } from "lucide-react";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { SelectField } from "@/components/ui/select";
import { formatToman } from "@/lib/utils";

type PaymentItem = {
  id: string;
  publicId: string;
  internalReference: string;
  registrationPublicId: string;
  payerName: string;
  participantNames: string;
  participantMobiles: string;
  tournamentTitle: string;
  method: string;
  amount: number;
  status: string;
  cardLast4: string | null;
  trackingCode: string | null;
  paidOn: string | null;
  paidTime: string | null;
  submittedAt: string | null;
  rejectedReason?: string | null;
  receiptUrl: string | null;
  createdAt: string;
};

const statusTitle: Record<string, string> = {
  PENDING: "در انتظار",
  APPROVED: "تأییدشده",
  REJECTED: "ردشده",
  EXPIRED: "منقضی",
  CANCELLED: "لغوشده",
  REFUNDED: "بازگشت وجه"
};

const methodTitle: Record<string, string> = {
  card_to_card: "کارت‌به‌کارت",
  pos: "کارتخوان حضوری",
  cash: "نقدی حضوری",
  receipt: "انتقال بانکی قدیمی",
  online: "درگاه قدیمی",
  mock: "آزمایشی"
};

const methodOptions = [
  { value: "all", label: "همه روش‌ها" },
  { value: "card_to_card", label: "کارت‌به‌کارت" },
  { value: "pos", label: "کارتخوان حضوری" },
  { value: "cash", label: "نقدی حضوری" }
];

const statusOptions = [
  { value: "all", label: "همه وضعیت‌ها" },
  { value: "needs_review", label: "نیازمند بررسی" },
  { value: "onsite", label: "در انتظار پرداخت حضوری" },
  { value: "APPROVED", label: "تأییدشده" },
  { value: "REJECTED", label: "ردشده" }
];

function paymentStatusTitle(item: PaymentItem) {
  if (item.status === "PENDING" && item.method === "card_to_card" && item.submittedAt) return "نیازمند بررسی";
  if (item.status === "PENDING" && ["pos", "cash"].includes(item.method)) return "در انتظار پرداخت حضوری";
  return statusTitle[item.status] || item.status;
}

function formatDate(value: string | null) {
  if (!value) return "—";
  const date = new Date(`${value}T12:00:00`);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("fa-IR").format(date);
}

export function PaymentsManager() {
  const [items, setItems] = useState<PaymentItem[]>([]);
  const [query, setQuery] = useState("");
  const [methodFilter, setMethodFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("needs_review");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState("");
  const [copied, setCopied] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const response = await fetch("/api/admin/payments", { cache: "no-store" });
    const payload = await response.json();
    setLoading(false);
    if (!response.ok) return setError(payload.message || "دریافت پرداخت‌ها انجام نشد.");
    setItems(payload.items || []);
  }

  useEffect(() => { void load(); }, []);

  const stats = useMemo(() => ({
    review: items.filter((item) => item.status === "PENDING" && item.method === "card_to_card" && item.submittedAt).length,
    onsite: items.filter((item) => item.status === "PENDING" && ["pos", "cash"].includes(item.method)).length,
    approved: items.filter((item) => item.status === "APPROVED").length
  }), [items]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => {
      const matchesQuery = !needle || [
        item.internalReference,
        item.payerName,
        item.participantNames,
        item.participantMobiles,
        item.tournamentTitle,
        item.trackingCode || "",
        item.cardLast4 || "",
        String(item.amount),
        item.status
      ].join(" ").toLowerCase().includes(needle);
      const matchesMethod = methodFilter === "all" || item.method === methodFilter;
      const matchesStatus = statusFilter === "all"
        || (statusFilter === "needs_review" && item.status === "PENDING" && item.method === "card_to_card" && Boolean(item.submittedAt))
        || (statusFilter === "onsite" && item.status === "PENDING" && ["pos", "cash"].includes(item.method))
        || item.status === statusFilter;
      return matchesQuery && matchesMethod && matchesStatus;
    });
  }, [items, methodFilter, query, statusFilter]);

  async function copyValue(value: string, key: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      window.setTimeout(() => setCopied(""), 1400);
    } catch {
      setError("کپی خودکار انجام نشد؛ مقدار را به‌صورت دستی انتخاب کنید.");
    }
  }

  async function update(item: PaymentItem, action: "approve" | "reject") {
    let reason = "";
    if (action === "approve") {
      const message = item.method === "card_to_card"
        ? `واریز ${formatToman(item.amount)} با کد پیگیری ${item.trackingCode || "—"} تأیید شود؟`
        : `پرداخت حضوری ${item.payerName} تأیید شود؟`;
      if (!window.confirm(message)) return;
    } else {
      reason = window.prompt("دلیل رد پرداخت را وارد کنید:", "اطلاعات پرداخت با تراکنش بانکی مطابقت ندارد.")?.trim() || "";
      if (!reason) return;
    }

    setBusyId(item.id);
    setError("");
    const response = await fetch(`/api/admin/payments/${item.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(action === "approve" ? { action } : { action, reason })
    });
    const payload = await response.json();
    setBusyId("");
    if (!response.ok) return setError(payload.message || "تغییر وضعیت پرداخت انجام نشد.");
    setItems((current) => current.map((currentItem) => currentItem.id === item.id ? {
      ...currentItem,
      status: payload.status,
      rejectedReason: reason || null
    } : currentItem));
  }

  return (
    <div>
      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Card className="p-4"><p className="text-xs text-[var(--muted)]">نیازمند بررسی بانکی</p><strong className="mt-2 block text-2xl text-amber-600">{stats.review.toLocaleString("fa-IR")}</strong></Card>
        <Card className="p-4"><p className="text-xs text-[var(--muted)]">در انتظار پرداخت حضوری</p><strong className="mt-2 block text-2xl text-sky-600">{stats.onsite.toLocaleString("fa-IR")}</strong></Card>
        <Card className="p-4"><p className="text-xs text-[var(--muted)]">پرداخت‌های تأییدشده</p><strong className="mt-2 block text-2xl text-emerald-600">{stats.approved.toLocaleString("fa-IR")}</strong></Card>
      </div>

      <div className="mt-5 grid gap-3 lg:grid-cols-[minmax(260px,1fr)_220px_220px]">
        <label className="relative block">
          <Search className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[var(--muted)]" size={17} />
          <Input className="pr-11" placeholder="نام، موبایل، مبلغ، کد پیگیری یا ۴ رقم کارت..." value={query} onChange={(event) => setQuery(event.target.value)} />
        </label>
        <SelectField value={statusFilter} onValueChange={setStatusFilter} options={statusOptions} ariaLabel="فیلتر وضعیت پرداخت" />
        <SelectField value={methodFilter} onValueChange={setMethodFilter} options={methodOptions} ariaLabel="فیلتر روش پرداخت" />
      </div>

      {error && <Alert tone="error" className="mt-4">{error}</Alert>}

      <div className="mt-5 grid gap-4">
        {filtered.map((item) => <Card key={item.id} className="p-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <strong className="text-base">{item.payerName}</strong>
                <span className="rounded-lg bg-[var(--surface-2)] px-2 py-1 text-[11px] font-bold text-[var(--muted)]" dir="ltr">{item.internalReference}</span>
              </div>
              <p className="mt-1 text-sm text-[var(--muted)]">{item.tournamentTitle}</p>
              <p className="mt-1 text-xs text-[var(--muted)]">شرکت‌کننده: {item.participantNames}</p>
              <p className="mt-1 text-xs text-[var(--muted)]" dir="ltr">{item.participantMobiles}</p>
            </div>
            <div className="text-left">
              <strong className="block text-lg text-[var(--brand)]">{formatToman(item.amount)}</strong>
              <span className="mt-1 block text-xs font-bold text-[var(--muted)]">{paymentStatusTitle(item)}</span>
            </div>
          </div>

          <div className="mt-4 grid gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-4 sm:grid-cols-2 xl:grid-cols-5">
            <Info title="روش پرداخت" value={methodTitle[item.method] || item.method} />
            {item.method === "card_to_card" && <>
              <Info title="کد پیگیری" value={item.trackingCode || "ثبت نشده"} copyLabel={copied === `${item.id}-tracking` ? "کپی شد" : "کپی"} onCopy={item.trackingCode ? () => copyValue(item.trackingCode!, `${item.id}-tracking`) : undefined} />
              <Info title="۴ رقم آخر کارت" value={item.cardLast4 ? `**** ${item.cardLast4}` : "ثبت نشده"} copyLabel={copied === `${item.id}-card` ? "کپی شد" : "کپی"} onCopy={item.cardLast4 ? () => copyValue(item.cardLast4!, `${item.id}-card`) : undefined} />
              <Info title="تاریخ واریز" value={formatDate(item.paidOn)} />
              <Info title="ساعت واریز" value={item.paidTime || "ثبت نشده"} />
            </>}
            {["pos", "cash"].includes(item.method) && <>
              <Info title="وضعیت صندوق" value={item.status === "PENDING" ? "هنوز تأیید نشده" : paymentStatusTitle(item)} />
              <Info title="مبلغ برای تطبیق" value={formatToman(item.amount)} copyLabel={copied === `${item.id}-amount` ? "کپی شد" : "کپی"} onCopy={() => copyValue(String(item.amount), `${item.id}-amount`)} />
            </>}
          </div>

          {item.rejectedReason && <Alert tone="error" className="mt-4">{item.rejectedReason}</Alert>}

          <div className="mt-4 flex flex-wrap items-center gap-2">
            {item.receiptUrl && <Button href={item.receiptUrl} target="_blank" rel="noreferrer" variant="secondary" size="sm"><Eye size={15} />مشاهده رسید اختیاری</Button>}
            {item.method === "card_to_card" && item.trackingCode && <Button type="button" variant="secondary" size="sm" onClick={() => copyValue(item.trackingCode!, `${item.id}-tracking-main`)}><Clipboard size={15} />{copied === `${item.id}-tracking-main` ? "کد کپی شد" : "کپی کد برای جست‌وجوی SMS"}</Button>}
            {!['APPROVED', 'REFUNDED', 'CANCELLED'].includes(item.status) && <Button type="button" disabled={busyId === item.id} loading={busyId === item.id} onClick={() => update(item, "approve")} variant="soft" size="sm"><Check size={15} />{["pos", "cash"].includes(item.method) ? "ثبت دریافت در صندوق" : "تأیید واریز"}</Button>}
            {!['APPROVED', 'REFUNDED', 'CANCELLED'].includes(item.status) && <Button type="button" disabled={busyId === item.id} onClick={() => update(item, "reject")} variant="dangerSoft" size="sm"><X size={15} />رد پرداخت</Button>}
          </div>
        </Card>)}

        {!loading && !filtered.length && <Card className="p-10 text-center text-[var(--muted)]">پرداختی با این فیلتر پیدا نشد.</Card>}
        {loading && <Card className="p-10 text-center text-[var(--muted)]">در حال دریافت...</Card>}
      </div>
    </div>
  );
}

function Info({ title, value, onCopy, copyLabel }: { title: string; value: string; onCopy?: () => void; copyLabel?: string }) {
  return <div className="min-w-0">
    <p className="text-[11px] text-[var(--muted)]">{title}</p>
    <div className="mt-1 flex items-center gap-2">
      <strong className="truncate text-sm" dir={/[0-9]/.test(value) ? "ltr" : undefined}>{value}</strong>
      {onCopy && <Button type="button" onClick={onCopy} variant="ghost" size="sm" className="h-6 px-1 text-[10px] text-[var(--brand)]">{copyLabel || "کپی"}</Button>}
    </div>
  </div>;
}
