import { env } from "@/lib/env";

type SmsParameter = { name: string; value: string };

async function sendSmsIrTemplate(mobile: string, templateId: number, parameters: SmsParameter[]) {
  if (!templateId) return { provider: "smsir" as const, skipped: true as const };
  if (!env.smsIrApiKey) throw new Error("SMSIR_CONFIGURATION_MISSING");

  const response = await fetch("https://api.sms.ir/v1/send/verify", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "X-API-KEY": env.smsIrApiKey
    },
    body: JSON.stringify({ mobile, templateId, parameters }),
    cache: "no-store"
  });

  const payload = await response.json().catch(() => null) as { status?: number; message?: string } | null;
  if (!response.ok || payload?.status !== 1) {
    throw new Error(payload?.message || "SMSIR_SEND_FAILED");
  }

  return { provider: "smsir" as const, skipped: false as const };
}

export async function sendOtpSms(mobile: string, code: string) {
  if (env.smsProvider === "mock") {
    if (process.env.NODE_ENV === "production") {
      throw new Error("SMS_PROVIDER_NOT_CONFIGURED");
    }
    return { provider: "mock" as const, debugCode: code };
  }

  if (!env.smsIrTemplateId) {
    throw new Error("SMSIR_CONFIGURATION_MISSING");
  }

  return sendSmsIrTemplate(mobile, env.smsIrTemplateId, [{ name: "Code", value: code }]);
}

export async function sendPaymentStatusSms({
  mobile,
  tournamentTitle,
  status,
  reason
}: {
  mobile: string;
  tournamentTitle: string;
  status: "APPROVED" | "REJECTED";
  reason?: string | null;
}) {
  if (env.smsProvider === "mock") {
    return { provider: "mock" as const, skipped: true as const };
  }

  const templateId = status === "APPROVED"
    ? env.smsIrPaymentApprovedTemplateId
    : env.smsIrPaymentRejectedTemplateId;

  const parameters: SmsParameter[] = [
    { name: "Tournament", value: tournamentTitle.slice(0, 80) }
  ];
  if (status === "REJECTED") {
    parameters.push({ name: "Reason", value: (reason || "نیاز به اصلاح اطلاعات پرداخت").slice(0, 120) });
  }

  return sendSmsIrTemplate(mobile, templateId, parameters);
}
