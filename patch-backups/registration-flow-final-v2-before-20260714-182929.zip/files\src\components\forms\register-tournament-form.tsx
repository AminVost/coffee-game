"use client";

import { useMemo, useState } from "react";
import { Banknote, CheckCircle2, CreditCard, Plus, ReceiptText, Trash2, Upload } from "lucide-react";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label, FieldHint } from "@/components/ui/label";
import { SelectField } from "@/components/ui/select";
import { formatToman } from "@/lib/utils";
import type { Tournament } from "@/types";

type PlayerInput = { name: string; mobile: string };
type PaymentMethod = "card_to_card" | "pos" | "cash";

const paymentOptions = [
  { value: "card_to_card", label: "کارت‌به‌کارت / انتقال بانکی" },
  { value: "pos", label: "کارتخوان حضوری" },
  { value: "cash", label: "پرداخت نقدی حضوری" }
];

function localDateValue() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function RegisterTournamentForm({ tournament }: { tournament: Tournament }) {
  const teamSize = useMemo(() => {
    const match = tournament.participantMode.match(/تیمی\s+(\d+)/);
    return match ? Number(match[1]) : 0;
  }, [tournament.participantMode]);
  const isTeam = teamSize > 0;
  const [players, setPlayers] = useState<PlayerInput[]>(Array.from({ length: isTeam ? teamSize : 1 }, () => ({ name: "", mobile: "" })));
  const [teamTitle, setTeamTitle] = useState("");
  const [payment, setPayment] = useState<PaymentMethod>("card_to_card");
  const [payerName, setPayerName] = useState("");
  const [cardLast4, setCardLast4] = useState("");
  const [bankTrackingCode, setBankTrackingCode] = useState("");
  const [paidOn, setPaidOn] = useState(localDateValue);
  const [paidTime, setPaidTime] = useState("");
  const [receipt, setReceipt] = useState<File | null>(null);
  const [result, setResult] = useState<{ status: string; trackingCode: string; paymentMethod: PaymentMethod; reservedUntil?: string | null; receiptWarning?: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const totalAmount = tournament.price * (isTeam ? 1 : players.length);

  function update(index: number, key: keyof PlayerInput, value: string) {
    setPlayers((items) => items.map((item, itemIndex) => itemIndex === index ? { ...item, [key]: value } : item));
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");

    const normalizedMobiles = players.map((player) => player.mobile.trim());
    if (new Set(normalizedMobiles).size !== normalizedMobiles.length) {
      setError("هر شماره موبایل را فقط یک‌بار وارد کنید.");
      return;
    }

    if (payment === "card_to_card") {
      if (payerName.trim().length < 2) {
        setError("نام واریزکننده را وارد کنید.");
        return;
      }
      if (!/^\d{4}$/.test(cardLast4)) {
        setError("۴ رقم آخر کارت واریزکننده را صحیح وارد کنید.");
        return;
      }
      if (bankTrackingCode.trim().length < 4) {
        setError("کد پیگیری انتقال را وارد کنید.");
        return;
      }
      if (!paidOn) {
        setError("تاریخ واریز را وارد کنید.");
        return;
      }
    }

    setLoading(true);
    try {
      const response = await fetch("/api/registrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tournamentId: tournament.id,
          players,
          payment,
          teamTitle: isTeam ? teamTitle : undefined,
          paymentDetails: payment === "card_to_card" ? {
            payerName,
            cardLast4,
            trackingCode: bankTrackingCode,
            paidOn,
            paidTime: paidTime || undefined
          } : undefined
        })
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.message || "ثبت‌نام انجام نشد.");

      let receiptWarning = "";
      if (payment === "card_to_card" && receipt && payload.paymentId) {
        const form = new FormData();
        form.set("paymentId", payload.paymentId);
        form.set("file", receipt);
        if (payload.receiptToken) form.set("receiptToken", payload.receiptToken);
        const uploadResponse = await fetch("/api/payments/receipts", { method: "POST", body: form });
        const uploadPayload = await uploadResponse.json();
        if (!uploadResponse.ok) {
          receiptWarning = uploadPayload.message || "اطلاعات واریز ثبت شد، اما تصویر اختیاری رسید بارگذاری نشد.";
        }
      }

      setResult({ status: payload.status, trackingCode: payload.trackingCode, paymentMethod: payment, reservedUntil: payload.reservedUntil || null, receiptWarning });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "ثبت‌نام انجام نشد.");
    } finally {
      setLoading(false);
    }
  }

  if (result) {
    const isWaitlisted = result.status === "WAITLISTED";
    const title = isWaitlisted
      ? "در لیست انتظار ثبت شدید"
      : result.paymentMethod === "card_to_card"
        ? "اطلاعات واریز برای بررسی ارسال شد"
        : "رزرو اولیه ثبت شد";
    const description = isWaitlisted
      ? "در صورت آزاد شدن ظرفیت با شما هماهنگ می‌شود."
      : result.paymentMethod === "card_to_card"
        ? "پس از تطبیق اطلاعات انتقال توسط مدیر، ثبت‌نام شما نهایی می‌شود."
        : result.reservedUntil
          ? `برای حفظ ظرفیت، پرداخت حضوری را تا ${new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit" }).format(new Date(result.reservedUntil))} انجام دهید.`
          : "پس از پرداخت حضوری و تأیید صندوق، ثبت‌نام شما نهایی می‌شود.";

    return <div className="rounded-[1.75rem] border border-emerald-500/25 bg-emerald-500/10 p-7 text-center">
      <CheckCircle2 className="mx-auto text-emerald-500" size={48} />
      <h3 className="mt-4 text-xl font-black">{title}</h3>
      <p className="mt-2 text-sm leading-7 text-[var(--muted)]">{description}</p>
      <p className="mt-3 text-sm">کد پیگیری ثبت‌نام: <strong dir="ltr">{result.trackingCode}</strong></p>
      {result.receiptWarning && <Alert tone="warning" className="mt-4 text-right">{result.receiptWarning}</Alert>}
    </div>;
  }

  return <form onSubmit={submit} className="grid gap-5">
    <div>
      <h3 className="font-black">{isTeam ? "اعضای تیم" : "شرکت‌کنندگان"}</h3>
      <p className="mt-1 text-xs text-[var(--muted)]">{isTeam ? `برای این مسابقه باید ${teamSize.toLocaleString("fa-IR")} عضو وارد شود.` : "می‌توانید چند شرکت‌کننده با شماره‌های متفاوت ثبت کنید."}</p>
    </div>

    {isTeam && <Label>نام تیم<Input value={teamTitle} onChange={(event) => setTeamTitle(event.target.value)} placeholder="مثلاً تیم توربو" required /></Label>}

    {players.map((player, index) => <div key={index} className="grid gap-3 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-4 sm:grid-cols-[1fr_1fr_auto]">
      <Input placeholder="نام و نام خانوادگی" value={player.name} onChange={(event) => update(index, "name", event.target.value)} required />
      <Input placeholder="شماره موبایل" dir="ltr" inputMode="tel" value={player.mobile} onChange={(event) => update(index, "mobile", event.target.value.replace(/\D/g, "").slice(0, 11))} pattern="09[0-9]{9}" required />
      <Button type="button" variant="dangerSoft" size="icon" disabled={isTeam || players.length === 1} onClick={() => setPlayers(players.filter((_, itemIndex) => itemIndex !== index))} aria-label="حذف شرکت‌کننده"><Trash2 size={17} /></Button>
    </div>)}

    {!isTeam && <Button type="button" variant="secondary" onClick={() => setPlayers([...players, { name: "", mobile: "" }])}><Plus size={17} />افزودن شرکت‌کننده دیگر</Button>}

    <div className="rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-4">
      <div className="flex items-center justify-between gap-3">
        <span className="text-sm font-bold text-[var(--muted)]">مبلغ قابل پرداخت</span>
        <strong className="text-lg text-[var(--brand)]">{formatToman(totalAmount)}</strong>
      </div>
    </div>

    <Label>روش پرداخت<SelectField value={payment} onValueChange={(value) => setPayment(value as PaymentMethod)} options={paymentOptions} /></Label>

    {payment === "card_to_card" && <div className="grid gap-4 rounded-2xl border border-[var(--line)] bg-[var(--surface-2)] p-4">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--brand)]/12 text-[var(--brand)]"><CreditCard size={19} /></span>
        <div><strong className="text-sm">اطلاعات انتقال بانکی</strong><p className="mt-1 text-xs leading-6 text-[var(--muted)]">مدیر با کد پیگیری، مبلغ و ۴ رقم آخر کارت، واریز را با پیامک بانک تطبیق می‌دهد.</p></div>
      </div>
      <Label>نام و نام خانوادگی واریزکننده<Input value={payerName} onChange={(event) => setPayerName(event.target.value)} maxLength={120} placeholder="نام صاحب کارت یا حساب" required /></Label>
      <div className="grid gap-4 sm:grid-cols-2">
        <Label>۴ رقم آخر کارت<Input value={cardLast4} onChange={(event) => setCardLast4(event.target.value.replace(/\D/g, "").slice(0, 4))} dir="ltr" inputMode="numeric" pattern="[0-9]{4}" placeholder="مثلاً 5531" required /></Label>
        <Label>کد پیگیری<Input value={bankTrackingCode} onChange={(event) => setBankTrackingCode(event.target.value.replace(/\s/g, "").slice(0, 64))} dir="ltr" inputMode="numeric" placeholder="کد پیگیری انتقال" required /></Label>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Label>تاریخ واریز<Input type="date" value={paidOn} onChange={(event) => setPaidOn(event.target.value)} required /></Label>
        <Label>ساعت واریز <span className="font-normal text-[var(--muted)]">(اختیاری)</span><Input type="time" value={paidTime} onChange={(event) => setPaidTime(event.target.value)} /></Label>
      </div>
      <Label>تصویر رسید <span className="font-normal text-[var(--muted)]">(اختیاری)</span>
        <div className="rounded-2xl border border-dashed border-[var(--line-strong)] bg-[var(--surface)] p-4">
          <div className="flex items-center gap-3"><Upload size={18} className="text-[var(--brand)]" /><Input className="h-auto border-0 bg-transparent p-0 shadow-none focus:ring-0" type="file" accept="image/jpeg,image/png,application/pdf" onChange={(event) => setReceipt(event.target.files?.[0] || null)} /></div>
        </div>
        <FieldHint>ارسال عکس اجباری نیست. JPG، PNG یا PDF حداکثر ۵ مگابایت</FieldHint>
      </Label>
    </div>}

    {payment === "pos" && <Alert tone="info"><span className="inline-flex items-center gap-2 font-bold"><ReceiptText size={17} />پرداخت با کارتخوان حضوری</span><span className="mt-1 block text-xs leading-6">پس از پرداخت در صندوق، مدیر پرداخت را در پنل تأیید می‌کند.</span></Alert>}
    {payment === "cash" && <Alert tone="info"><span className="inline-flex items-center gap-2 font-bold"><Banknote size={17} />پرداخت نقدی حضوری</span><span className="mt-1 block text-xs leading-6">پس از تحویل وجه در صندوق، مدیر پرداخت را در پنل تأیید می‌کند.</span></Alert>}

    {error && <Alert tone="error">{error}</Alert>}
    <Button type="submit" loading={loading} loadingText="در حال ثبت...">{payment === "card_to_card" ? "ارسال اطلاعات و ثبت‌نام" : `ثبت رزرو ${isTeam ? "تیم" : "شرکت‌کنندگان"}`}</Button>
  </form>;
}
