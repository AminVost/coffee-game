import { NextResponse } from "next/server";
import { z } from "zod";
import type { RowDataPacket } from "mysql2";
import { authorize } from "@/lib/authorization";
import { writeAuditLog } from "@/lib/audit";
import { db, queryRows } from "@/lib/db";
import { env } from "@/lib/env";
import { sendPaymentStatusSms } from "@/lib/sms";

const schema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("approve") }),
  z.object({ action: z.literal("reject"), reason: z.string().trim().min(3).max(500) })
]);

type PaymentRow = RowDataPacket & {
  id: number;
  status: string;
  method: string;
  registration_id: number;
  tournament_id: number;
  registration_slots: number;
  tournament_capacity: number;
  buyer_user_id: number | null;
  payer_name: string | null;
  payer_card_last4: string | null;
  tracking_code: string | null;
  paid_on: string | Date | null;
  tournament_title: string;
};

type MobileRow = RowDataPacket & { mobile: string };
type CountRow = RowDataPacket & { occupied_slots: number };

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await authorize("payments.approve");
  if (auth.response) return auth.response;

  try {
    const input = schema.parse(await request.json());
    const { id } = await params;

    if (env.dataMode === "mock") {
      return NextResponse.json({ ok: true, status: input.action === "approve" ? "APPROVED" : "REJECTED" });
    }

    const rows = await queryRows<PaymentRow[]>(`
      SELECT p.id,p.status,p.method,p.registration_id,r.tournament_id,
             r.slots AS registration_slots,t.capacity AS tournament_capacity,
             COALESCE(p.user_id,r.buyer_user_id) AS buyer_user_id,
             p.payer_name,p.payer_card_last4,p.tracking_code,p.paid_on,
             t.title AS tournament_title
      FROM payments p
      JOIN registrations r ON r.id=p.registration_id
      JOIN tournaments t ON t.id=r.tournament_id
      WHERE p.id=?
      LIMIT 1
    `, [id]);
    const payment = rows[0];
    if (!payment) return NextResponse.json({ message: "پرداخت یافت نشد." }, { status: 404 });
    if (["APPROVED", "REFUNDED", "CANCELLED"].includes(payment.status)) {
      return NextResponse.json({ message: "این پرداخت قبلاً نهایی شده است." }, { status: 409 });
    }

    if (input.action === "approve" && payment.method === "card_to_card") {
      const hasRequiredDetails = Boolean(
        payment.payer_name && payment.payer_card_last4 && payment.tracking_code && payment.paid_on
      );
      if (!hasRequiredDetails) {
        return NextResponse.json({ message: "اطلاعات انتقال بانکی کامل نیست و قابل تأیید نیست." }, { status: 422 });
      }
    }

    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      if (input.action === "approve") {
        await connection.query(`SELECT id FROM tournaments WHERE id=? FOR UPDATE`, [payment.tournament_id]);
        const [countRows] = await connection.query<CountRow[]>(`
          SELECT COALESCE(SUM(
            CASE
              WHEN status IN ('RESERVED','PENDING_APPROVAL','CONFIRMED','CHECKED_IN') THEN slots
              WHEN status='PENDING_PAYMENT' AND (reserved_until IS NULL OR reserved_until>NOW()) THEN slots
              ELSE 0
            END
          ),0) AS occupied_slots
          FROM registrations
          WHERE tournament_id=? AND id<>? AND deleted_at IS NULL
        `, [payment.tournament_id, payment.registration_id]);
        const occupiedSlots = Number(countRows[0]?.occupied_slots || 0);
        if (occupiedSlots + Number(payment.registration_slots) > Number(payment.tournament_capacity)) {
          await connection.rollback();
          return NextResponse.json({
            message: "ظرفیت مسابقه تکمیل شده و این پرداخت قابل تأیید نیست. ابتدا ظرفیت را بررسی کنید."
          }, { status: 409 });
        }

        await connection.execute(`
          UPDATE payments
          SET status='APPROVED',approved_by=?,approved_at=NOW(),rejected_reason=NULL,updated_at=NOW()
          WHERE id=?
        `, [auth.user.id, payment.id]);
        await connection.execute(`
          UPDATE registrations SET status='CONFIRMED',reserved_until=NULL,updated_at=NOW()
          WHERE id=? AND status NOT IN ('CANCELLED','REJECTED','WAITLISTED')
        `, [payment.registration_id]);
        await connection.execute(`
          UPDATE registration_entries
          SET confirmed_at=COALESCE(confirmed_at,NOW())
          WHERE registration_id=?
        `, [payment.registration_id]);

        if (payment.buyer_user_id) {
          await connection.execute(`
            INSERT INTO notifications(user_id,type,title,body,data,created_at)
            VALUES(?,?,?,?,?,NOW())
          `, [
            payment.buyer_user_id,
            "payment_approved",
            "پرداخت تأیید شد",
            `پرداخت ثبت‌نام مسابقه ${payment.tournament_title} تأیید شد.`,
            JSON.stringify({ paymentId: payment.id, registrationId: payment.registration_id })
          ]);
        }
      } else {
        await connection.execute(`
          UPDATE payments
          SET status='REJECTED',approved_by=NULL,approved_at=NULL,rejected_reason=?,updated_at=NOW()
          WHERE id=?
        `, [input.reason, payment.id]);
        await connection.execute(`
          UPDATE registrations SET status='PENDING_PAYMENT',updated_at=NOW()
          WHERE id=? AND status NOT IN ('CANCELLED','REJECTED','WAITLISTED')
        `, [payment.registration_id]);
        await connection.execute(`
          UPDATE registration_entries SET confirmed_at=NULL WHERE registration_id=?
        `, [payment.registration_id]);

        if (payment.buyer_user_id) {
          await connection.execute(`
            INSERT INTO notifications(user_id,type,title,body,data,created_at)
            VALUES(?,?,?,?,?,NOW())
          `, [
            payment.buyer_user_id,
            "payment_rejected",
            "پرداخت نیاز به اصلاح دارد",
            `پرداخت ثبت‌نام مسابقه ${payment.tournament_title} تأیید نشد: ${input.reason}`,
            JSON.stringify({ paymentId: payment.id, registrationId: payment.registration_id })
          ]);
        }
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }

    const status = input.action === "approve" ? "APPROVED" : "REJECTED";

    try {
      const mobileRows = await queryRows<MobileRow[]>(`
        SELECT DISTINCT p.mobile
        FROM registration_entries re
        JOIN players p ON p.id=re.player_id
        WHERE re.registration_id=? AND p.mobile IS NOT NULL
        UNION
        SELECT DISTINCT tp.mobile
        FROM registration_entries re
        JOIN teams tm ON tm.id=re.team_id
        JOIN team_members tmem ON tmem.team_id=tm.id
        JOIN players tp ON tp.id=tmem.player_id
        WHERE re.registration_id=? AND tp.mobile IS NOT NULL
      `, [payment.registration_id, payment.registration_id]);

      const smsResults = await Promise.allSettled(mobileRows.map((row) => sendPaymentStatusSms({
        mobile: row.mobile,
        tournamentTitle: payment.tournament_title,
        status,
        reason: input.action === "reject" ? input.reason : null
      })));
      smsResults.forEach((result, index) => {
        if (result.status === "rejected") {
          console.error("payment.status.sms.failed", {
            paymentId: payment.id,
            mobile: mobileRows[index]?.mobile,
            error: result.reason
          });
        }
      });
    } catch (smsError) {
      console.error("payment.status.sms.lookup_failed", { paymentId: payment.id, error: smsError });
    }

    await writeAuditLog({
      actorUserId: auth.user.id,
      action: input.action === "approve" ? "payment.approved" : "payment.rejected",
      entityType: "payment",
      entityId: payment.id,
      oldData: { status: payment.status },
      newData: { status, reason: input.action === "reject" ? input.reason : null, method: payment.method },
      request
    });

    return NextResponse.json({ ok: true, status });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: "اطلاعات عملیات پرداخت نامعتبر است." }, { status: 422 });
    }
    console.error("admin.payment.update.failed", error);
    return NextResponse.json({ message: "تغییر وضعیت پرداخت انجام نشد." }, { status: 500 });
  }
}
