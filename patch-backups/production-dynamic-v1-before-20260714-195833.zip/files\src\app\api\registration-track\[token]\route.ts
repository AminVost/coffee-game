import { NextResponse } from "next/server";
import { env } from "@/lib/env";
import { findRegistrationTracking } from "@/lib/repositories/registration-tracking";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;

  if (env.dataMode === "mock") {
    return NextResponse.json({
      item: {
        trackingCode: "CGS-DEMO12345",
        tournamentTitle: "مسابقه آزمایشی",
        tournamentSlug: "demo",
        startsAt: new Date(Date.now() + 86400000).toISOString(),
        venue: "Coffee Game ستارخان",
        registrationStatus: "PENDING_APPROVAL",
        registrationStatusTitle: "در انتظار بررسی پرداخت",
        paymentStatus: "PENDING",
        paymentStatusTitle: "در انتظار بررسی",
        paymentMethod: "card_to_card",
        paymentMethodTitle: "کارت‌به‌کارت / انتقال بانکی",
        amount: 350000,
        slots: 1,
        maskedMobile: "09*****0000",
        maskedCard: "**** 5531",
        submittedAt: new Date().toISOString(),
        rejectedReason: null,
        correctionExpiresAt: null,
        updatedAt: new Date().toISOString(),
        nextAction: "اطلاعات پرداخت ارسال شده است؛ منتظر بررسی مدیر باشید."
      }
    });
  }

  const item = await findRegistrationTracking(token);
  if (!item) {
    return NextResponse.json({ message: "کد یا لینک پیگیری معتبر نیست." }, { status: 404 });
  }

  return NextResponse.json({ item });
}
