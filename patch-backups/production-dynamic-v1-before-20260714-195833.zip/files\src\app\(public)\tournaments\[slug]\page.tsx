import { notFound } from "next/navigation";
import {
  CalendarDays,
  Check,
  Clock3,
  MapPin,
  Share2,
  Trophy,
  Users
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RegisterTournamentForm } from "@/components/forms/register-tournament-form";
import { getSession } from "@/lib/auth";
import { findTournament } from "@/lib/repositories/tournaments";
import { formatToman } from "@/lib/utils";

export default async function TournamentDetail({
  params
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [item, user] = await Promise.all([
    findTournament(slug),
    getSession()
  ]);

  if (!item) notFound();

  const left = Math.max(0, item.capacity - item.registered);

  return (
    <div className="page-shell">
      <div
        className="overflow-hidden rounded-[2.5rem] p-7 text-white sm:p-12"
        style={{ background: item.cover }}
      >
        <div className="max-w-3xl">
          <div className="flex flex-wrap gap-2">
            <Badge className="border-white/15 bg-black/30 text-white">{item.status}</Badge>
            <Badge className="border-white/15 bg-black/30 text-white">{item.gameTitle}</Badge>
            <Badge className="border-white/15 bg-black/30 text-white">{item.format}</Badge>
          </div>
          <h1 className="mt-6 text-3xl font-black sm:text-5xl">{item.title}</h1>
          <p className="mt-4 max-w-2xl leading-8 text-white/75">{item.description}</p>
          <div className="mt-7 flex flex-wrap gap-4 text-sm font-bold">
            <span className="flex items-center gap-2"><CalendarDays size={17} />{item.date}</span>
            <span className="flex items-center gap-2"><Clock3 size={17} />{item.time}</span>
            <span className="flex items-center gap-2"><MapPin size={17} />{item.venue}</span>
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_400px]">
        <div className="grid gap-6">
          <Card className="p-6">
            <h2 className="text-xl font-black">اطلاعات مسابقه</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Info
                icon={<Users />}
                title="ظرفیت"
                value={`${item.registered.toLocaleString("fa-IR")} از ${item.capacity.toLocaleString("fa-IR")} نفر`}
              />
              <Info icon={<Trophy />} title="جایزه" value={item.prize} />
              <Info icon={<Clock3 />} title="نوع شرکت" value={item.participantMode} />
              <Info icon={<MapPin />} title="محل" value={item.venue} />
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-black">قوانین اصلی</h2>
            <div className="mt-5 grid gap-3">
              {item.rules.map((rule) => (
                <div
                  key={rule}
                  className="flex items-center gap-3 rounded-2xl bg-[var(--surface-2)] p-4 text-sm font-bold"
                >
                  <Check size={17} className="text-[var(--brand)]" />
                  {rule}
                </div>
              ))}
            </div>
            <Button href="/rules" variant="ghost" className="mt-4">مشاهده قوانین کامل</Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-black">جدول و قرعه</h2>
            <p className="mt-3 text-sm leading-7 text-[var(--muted)]">
              پس از بسته‌شدن ثبت‌نام، قرعه در همین صفحه و بخش زنده منتشر می‌شود.
            </p>
            <div className="mt-5 grid grid-cols-4 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((number) => (
                <span
                  key={number}
                  className="rounded-xl border border-[var(--line)] bg-[var(--surface-2)] p-3 text-center text-xs font-bold"
                >
                  جایگاه {number.toLocaleString("fa-IR")}
                </span>
              ))}
            </div>
          </Card>
        </div>

        <aside className="grid h-fit gap-5 lg:sticky lg:top-24">
          <Card className="p-6">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-xs text-[var(--muted)]">هزینه ثبت‌نام هر نفر</p>
                <strong className="mt-1 block text-xl">{formatToman(item.price)}</strong>
              </div>
              <span className="text-sm font-black text-[var(--brand)]">
                {left.toLocaleString("fa-IR")} ظرفیت باقی‌مانده
              </span>
            </div>
            <div className="my-5 h-px bg-[var(--line)]" />
            <RegisterTournamentForm
              tournament={item}
              initialUser={user ? { name: user.name, mobile: user.mobile } : null}
            />
          </Card>
          <Button variant="secondary"><Share2 size={17} />اشتراک‌گذاری مسابقه</Button>
        </aside>
      </div>
    </div>
  );
}

function Info({
  icon,
  title,
  value
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
}) {
  return (
    <div className="flex gap-3 rounded-2xl border border-[var(--line)] p-4">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--brand)]/12 text-[var(--brand)]">
        {icon}
      </span>
      <div>
        <p className="text-xs text-[var(--muted)]">{title}</p>
        <strong className="mt-1 block text-sm">{value}</strong>
      </div>
    </div>
  );
}
